package uqu.jeelab.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import uqu.jeelab.model.cars;

public class carsDAO {
	

	private static String URL = "db4free.net:3306/quicklease";
	private static String user = "raghad";
	private static String password = "1372241998"; 
	
	private Connection connect = null;
	private ResultSet resultSet = null;
	
	private ArrayList resList = new ArrayList();
	
	public ArrayList getCars() throws Exception {

		try {
			connect = DriverManager.getConnection("jdbc:mysql://" + URL, user, password);
			
			Statement statement = connect.createStatement();
			
			String sql = "SELECT * FROM cars";
			resultSet = statement.executeQuery(sql);
			
			while (resultSet.next()) {
				String cars_name = resultSet.getString("cars_name");
				int price = resultSet.getInt("price");
				String borrowed = resultSet.getString("borrowed");
				resList.add(new cars(cars_name, price, borrowed));
				
			}
			
			return resList;
			
		}catch (Exception e) {
			throw e;
		} finally {
			close();
		}
	}

	private void close() {
		try {
			if(resultSet != null) {
				resultSet.close();
			}
			if(connect != null) {
				connect.close();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
