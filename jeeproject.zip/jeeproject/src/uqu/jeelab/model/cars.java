package uqu.jeelab.model;

public class cars {

	private String CarsName;
	private int Price;
	private String Borrowed;
	
	public cars(String cars_name, int price,String borrowed) {
		CarsName = cars_name;
		Price = price;
		Borrowed = borrowed;
		
	}
	

	public String getCarsName() {
		return CarsName;
	}

	public void setCarsName(String CarsName) {
		this.CarsName = CarsName;
	}
	
	public int getPrice() {
		return Price;
	}


	public void setPrice(int Price) {
		this.Price = Price;
	}


	public String getBorroweed() {
		return Borrowed;
	}

	public void setBorroweed(String Borrowed) {
		this.Borrowed = Borrowed;
	}

	
	
}
